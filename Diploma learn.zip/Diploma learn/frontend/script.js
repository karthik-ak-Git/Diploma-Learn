// Add model selection UI
const modelSelector = `
<div class="model-selector">
  <label>
    <input type="radio" name="model-type" value="standard" checked> Standard (3B)
  </label>
  <label>
    <input type="radio" name="model-type" value="deepreason"> DeepReason (7B)
  </label>
</div>
`;

document.querySelector('.chat-input').insertAdjacentHTML('afterbegin', modelSelector);

// Update sendQuery function
async function sendQuery() {
    const input = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');
    const mode = document.getElementById('mode-select').value;
    const useDeepReason = document.querySelector('input[name="model-type"]:checked').value === 'deepreason';

    // ... existing code ...

    const response = await fetch('http://192.168.1.14:5000/chat', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ 
            query: input.value, 
            mode: mode,
            deepreason: useDeepReason
        }),
    });

    // Update response display
    aiResponse.innerHTML = `
        <div class="model-info">
            ${data.mode} • ${data.model_used.split('/')[1]}
        </div>
        ${formatAiResponse(data.response)}
    `;
}